package Proxy;

interface Pessoa {
    public String getNome();
    public String getId();
}


