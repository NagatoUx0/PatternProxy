package Proxy;

class PessoaImpl implements Pessoa {
      private String nome;
      private String id;

      public PessoaImpl(String id, String nome){
        
        this.nome = nome;
        this.id = id;
        
        System.out.println("retornando resultado da pessoa no banco de dados ->"+ nome);
      }

      public String getNome(){
        return nome;
        
      }
      public String getId() {
        return this.id;
      }
}
