package Proxy;
import java.util.ArrayList;
import java.util.List;




class ProxyExample {

    public static void main(String[] args){
         List<Pessoa> pessoas = new ArrayList<Pessoa>();
         
         pessoas.add(new ProxyPessoa(" A" ));
         
         pessoas.add(new ProxyPessoa(" B "));
         
         pessoas.add(new ProxyPessoa(" C "));
         
         System.out.println("Gabriel:" + pessoas.get(2).getNome());
         
         System.out.println("Id da 1ª pessoa -"+ pessoas.get(2).getId());
      
         System.out.println("Alana:" + pessoas.get(0).getNome());
         
         System.out.println("Id da 2ª pessoa -"+ pessoas.get(0).getId());
 
         System.out.println("Amaro:" + pessoas.get(1).getNome());
         
         
    
      System.out.println("Id da 3ª pessoa -"+ pessoas.get(1).getId());
 
  }
         
  
} 


