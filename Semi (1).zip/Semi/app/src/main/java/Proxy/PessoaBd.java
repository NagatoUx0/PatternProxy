package Proxy;
import java.util.ArrayList;
import java.util.List;

class PessoaBd {
      
      public static Pessoa getPessoaByID(String id) {
      
      System.out.println("selecionando pessoas através do id -> "+id);
      return new PessoaImpl(id,"id"+id);
   
  }
}
