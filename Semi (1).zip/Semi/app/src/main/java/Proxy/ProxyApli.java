package Proxy;
import java.util.ArrayList;
import java.util.List;




class ProxyApli {

    public static void main(String[] args){
         List<Pessoa> nomes = new ArrayList<Pessoa>();
         
         nomes.add(new ProxyPessoa(" A" ));
         
         nomes.add(new ProxyPessoa(" B "));
         
         nomes.add(new ProxyPessoa(" C "));
         
       
         
         System.out.println("Gabriel:" + nomes.get(0).getNome());
         
         
      
         System.out.println("Alana:" + nomes.get(1).getNome());
         
         
 
         System.out.println("Amaro:" + nomes.get(2).getNome());
         
        
        
         
         
         System.out.println("Gabriel:" + nomes.get(0).getNome()); 
         
         
      
         System.out.println("Alana:" + nomes.get(1).getNome());
         
         
 
         System.out.println("Amaro:" + nomes.get(2).getNome());
         
        
         
         
         
         
         
         
         
      
         
 
  }
         
  
}
